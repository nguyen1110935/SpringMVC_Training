package com.csc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.csc.model.Fresher;
import com.csc.service.FresherService;

@Controller
public class IndexController {

	@Autowired
	private FresherService service;
	
	public FresherService getService() {
		return service;
	}

	public void setService(FresherService service) {
		this.service = service;
	}

	@RequestMapping(value = "/")
	public String index(){
		return "index";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String register(Map<String, Object> model){
		Fresher userForm = new Fresher();		
		model.put("userForm", userForm);
		
		List<String> professionList = new ArrayList<String>();
		professionList.add("Developer");
		professionList.add("Designer");
		professionList.add("IT Manager");
		model.put("professionList", professionList);
		
		return "Registration";
	}
	
	@RequestMapping(value = "/register" ,method = RequestMethod.POST)
	@ResponseBody
	public String doRegister(@ModelAttribute("userForm") Fresher fresher, Map<String, Object> model){
		service.saveOrUpdate(fresher);
		return fresher.toString();
	}
}
